/*For more information see notes.txt in the Documentation folder */
#include <gplib.h>   

#define _PPScriptMode_		// for enum mode, replace this with #define _EnumMode_
#include "../../Include/pp_proj.h"

int main(void)
{
	InitLibrary();  // Required for accessing Power PMAC library

					//Put your code here

	CloseLibrary();
	return 0;
}

